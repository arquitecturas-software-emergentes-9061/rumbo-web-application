import { validateGraph } from '../domain/model/graph-validation';
import { EditorGraph, PlanBounds } from '../domain/model/map-graph.types';
import { ModelProposal } from '../domain/model/plan-interpretation';
import { proposalGraphResult } from './proposal-graph';

const plan: PlanBounds = { floorId: 'floor', planVersionId: 'version', widthUnits: 100,
  heightUnits: 60, metersPerUnit: 1 };
const proposal = (doors: ModelProposal['doors'] = []): ModelProposal => ({
  zones: [], warnings: [], wallCandidates: [{ x1: 50, y1: 0, x2: 50, y2: 60 }], doors,
  nodes: [{ id: 'access', label: 'Entrada', role: 'ACCESS', x: 20, y: 30 },
    { id: 'destination', label: 'Destino', role: 'DESTINATION', x: 80, y: 30 }],
  connections: [{ id: 'route', fromNodeId: 'access', toNodeId: 'destination', distanceUnits: 60,
    graphType: 'CORRIDOR' }]
});

describe('generated model geometry and graph', () => {
  it('excludes a solid-wall crossing and reports it before saving', () => {
    const result = proposalGraphResult(proposal(), plan);
    expect(result.graph.walls).toHaveLength(1);
    expect(result.graph.connections).toHaveLength(0);
    expect(result.warnings.some(message => message.includes('se excluyó'))).toBe(true);
  });

  it('uses DOORWAY through a recognized opening and produces a valid graph', () => {
    const result = proposalGraphResult(proposal([{ id: 'opening', x1: 50, y1: 25, x2: 50, y2: 35 }]), plan);
    expect(result.graph.doors).toHaveLength(1);
    expect(result.graph.connections).toHaveLength(1);
    expect(result.graph.connections[0].type).toBe('DOORWAY');
    expect(validateGraph(result.graph, [plan]).filter(issue => issue.severity === 'error')).toEqual([]);
  });

  it('deduplicates links and respects walls already in the draft', () => {
    const input = proposal();
    input.wallCandidates = [];
    input.connections.push({ ...input.connections[0], id: 'duplicate', fromNodeId: 'destination',
      toNodeId: 'access' });
    const existing: EditorGraph = { nodes: [], connections: [], destinations: [],
      walls: [{ id: 'existing', floorId: plan.floorId, planVersionId: plan.planVersionId,
        x1: 50, y1: 0, x2: 50, y2: 60 }], doors: [] };
    const result = proposalGraphResult(input, plan, existing);
    expect(result.graph.walls?.map(wall => wall.id)).toEqual(['existing']);
    expect(result.graph.connections).toHaveLength(0);
    expect(proposalGraphResult(input, plan).graph.connections).toHaveLength(1);
  });
});
