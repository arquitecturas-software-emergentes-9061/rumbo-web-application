import { Injectable, inject } from '@angular/core';
import { map } from 'rxjs';
import { ConnectionType, EditorGraph, PlanBounds } from '../domain/model/map-graph.types';
import { ModelProposal } from '../domain/model/plan-interpretation';
import { PlanInterpretation } from './floor-plan.contracts';
import { FLOOR_PLANS_PORT } from './planning.ports';
import { previewPlan, proposalGraphResult, unadoptedProposalGeometry } from './proposal-graph';
import { isEmptyProposal } from './proposal-review';
import { validateGraph } from '../domain/model/graph-validation';

export type GeneratedModel =
  | { kind: 'preview-only'; interpretation: PlanInterpretation }
  | { kind: 'empty'; interpretation: PlanInterpretation }
  | { kind: 'candidate'; interpretation: PlanInterpretation; proposal: ModelProposal;
      plan: PlanBounds; graph: EditorGraph;
      unresolvedGeometry: Pick<ModelProposal, 'wallCandidates' | 'doors'> };

@Injectable({ providedIn: 'root' })
export class GenerateModelUseCase {
  private readonly plans = inject(FLOOR_PLANS_PORT);

  execute(siteId: string, floorId: string, versionId: string, currentPlan: PlanBounds | null,
          existing?: EditorGraph) {
    return this.plans.interpret(siteId, floorId, versionId).pipe(map(interpretation => {
      const proposal = interpretation.proposal;
      if (interpretation.processing !== 'SVG_CANDIDATES' || !proposal)
        return { kind: 'preview-only', interpretation } as GeneratedModel;
      if (isEmptyProposal(proposal)) return { kind: 'empty', interpretation } as GeneratedModel;
      const plan = previewPlan(proposal, floorId, versionId, currentPlan);
      const constructionStarted = performance.now();
      const result = proposalGraphResult(proposal, plan, existing);
      const validationStarted = performance.now();
      const accepted = new Map(result.graph.connections.map(link => [link.id, link]));
      const validation = validateGraph(result.graph, [plan]).filter(issue => issue.severity === 'error')
        .map(issue => issue.message);
      console.debug('[Generar modelo] construcción=' + (validationStarted - constructionStarted).toFixed(1)
        + 'ms validación=' + (performance.now() - validationStarted).toFixed(1) + 'ms');
      const reviewed = { ...proposal, connections: proposal.connections.flatMap(link => {
        const corrected = accepted.get(link.id);
        return corrected ? [{ ...link, graphType: corrected.type as ConnectionType,
          kind: corrected.type === 'CORRIDOR' ? 'CORRIDOR' : 'DOORWAY' }] : [];
      }),
        warnings: [...new Set([...proposal.warnings, ...result.warnings, ...validation])] };
      return { kind: 'candidate', interpretation, proposal: reviewed, plan, graph: result.graph,
        unresolvedGeometry: unadoptedProposalGeometry(reviewed, result.graph) } as GeneratedModel;
    }));
  }
}
